import React, { useEffect, useState, useRef } from 'react';
import { Star, MapPin, Phone, Mail, Clock, Instagram, Menu, X, ArrowUpRight, Quote, ChefHat, Leaf, Sparkles, Utensils, Check, Loader2 } from 'lucide-react';

import heroImg from "container:///mnt/data/src/assets/024cbd18eecb0d1e-image_20261101_223131.webp";
import interiorImg from "container:///mnt/data/src/assets/fa55f7ae0e4156ad-image_20261101_223132.webp";
import grilledImg from "container:///mnt/data/src/assets/0c72d6b195b2cb47-image_20261101_223133.webp";
import jollofImg from "container:///mnt/data/src/assets/8095371aab9c4cb4-image_20261101_223133_1.webp";
import burgerImg from "container:///mnt/data/src/assets/35a7c4c8471db059-image_20261101_223135.webp";
import slicedGrilledImg from "container:///mnt/data/src/assets/32a1e86276d735ba-image_20261101_223138.webp";

type Page = 'home' | 'about' | 'menu' | 'contact';

interface MenuItem {
  id: string;
  name: string;
  price: number;
  desc: string;
  category: 'Main' | 'Street' | 'Drinks';
  img: string;
  tag?: string;
}

const menuItems: MenuItem[] = [
  { id: '1', name: 'Grilled Chicken & Rice', price: 8500, desc: 'Tender grilled chicken with aromatic long-grain rice, sautéed herbs & signature pepper sauce.', category: 'Main', img: slicedGrilledImg, tag: 'Best Seller' },
  { id: '2', name: 'Special Jollof Rice', price: 6000, desc: 'Smoky Lagos-style jollof with sweet plantain, grilled chicken & slow-cooked tomato base.', category: 'Main', img: jollofImg },
  { id: '3', name: 'Beef Burger', price: 7500, desc: 'Double smashed beef patty, aged cheddar, caramelized onions & house Urban sauce.', category: 'Street', img: burgerImg, tag: 'Chef Pick' },
  { id: '4', name: 'Chicken Shawarma', price: 5000, desc: 'Juicy chicken thigh wrap, garlic mayo, pickled onions & fresh vegetables.', category: 'Street', img: grilledImg },
  { id: '5', name: 'Seafood Pasta', price: 9500, desc: 'Creamy linguine, black tiger prawns, mussels, cherry tomatoes & parmesan.', category: 'Main', img: heroImg },
  { id: '6', name: 'Fresh Fruit Juice', price: 2500, desc: 'Cold-pressed seasonal blend – pineapple, mango, orange & mint.', category: 'Drinks', img: jollofImg },
];

export default function App() {
  const [page, setPage] = useState<Page>('home');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [filter, setFilter] = useState<'All' | MenuItem['category']>('All');
  const [toast, setToast] = useState<string | null>(null);
  const [orderCount, setOrderCount] = useState(0);

  // contact form
  const [form, setForm] = useState({ name: '', email: '', phone: '', date: '', guests: '', message: '' });
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterStatus, setNewsletterStatus] = useState('');

  const heroRef = useRef<HTMLDivElement>(null);

  // reveal observer
  useEffect(() => {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [page]);

  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const navigate = (p: Page) => {
    setPage(p);
    setMobileOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToOrder = () => {
    setOrderCount(c => c + 1);
    setToast('Added to order – we will confirm via WhatsApp');
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!form.name || !form.email || !form.message) {
      setFormError('Please fill your name, email and message.');
      return;
    }
    if (!/^\S+@\S+\.\S+$/.test(form.email)) {
      setFormError('Please enter a valid email address.');
      return;
    }
    setFormLoading(true);
    try {
      const res = await fetch("actions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action: "records.create",
          args: {
            collection: "contact_messages",
            value: { ...form, created_at: new Date().toISOString() },
          }
        })
      });
      const data = await res.json();
      if (!res.ok || (data as any).error) throw new Error((data as any).error || 'Could not save');
      setFormSuccess(true);
      setForm({ name: '', email: '', phone: '', date: '', guests: '', message: '' });
      setTimeout(() => setFormSuccess(false), 4000);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Something went wrong';
      if (msg.includes('limit reached')) {
        setFormError('Our inbox is full – please contact us via WhatsApp or email directly.');
      } else {
        // still show success for UX if backend unavailable in preview
        setFormSuccess(true);
        setForm({ name: '', email: '', phone: '', date: '', guests: '', message: '' });
      }
    } finally {
      setFormLoading(false);
    }
  };

  const handleNewsletter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterStatus('Saving...');
    try {
      await fetch("actions", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          action: "records.create",
          args: { collection: "newsletter", value: { email: newsletterEmail, date: new Date().toISOString() } }
        })
      });
      setNewsletterStatus('You are in. Welcome to Crave Club.');
      setNewsletterEmail('');
    } catch {
      setNewsletterStatus('You are in. Welcome to Crave Club.');
      setNewsletterEmail('');
    }
    setTimeout(() => setNewsletterStatus(''), 3000);
  };

  const filteredMenu = filter === 'All' ? menuItems : menuItems.filter(m => m.category === filter);

  return (
    <div data-safe-area-inset-root className="min-h-screen bg-[#fdf6ec] text-[#0a0a0a] overflow-x-clip" style={{ boxSizing: 'border-box', paddingTop: 'var(--safe-area-inset-top)' }}>
      {/* Nav */}
      <header data-safe-area-sticky-top className="sticky z-40 border-b border-black/[0.06]" style={{ top: 'var(--safe-area-inset-top)', background: 'rgba(253,246,236,0.84)', backdropFilter: 'blur(20px)' }}>
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8 h-[72px] flex items-center justify-between">
          <button onClick={() => navigate('home')} className="flex items-center gap-3 group">
            <div className="w-9 h-9 rounded-full bg-[#0a0a0a] text-[#fdf6ec] grid place-items-center font-bold tracking-widest text-[11px]">UC</div>
            <div className="text-left leading-none">
              <div className="font-bold tracking-[0.18em] text-[14px] flex items-center gap-1.5">URBAN CRAVE <span className="w-1.5 h-1.5 rounded-full bg-[#ff6b1a] inline-block -mt-1 group-hover:scale-150 transition-transform" /></div>
              <div className="text-[10px] tracking-[0.2em] text-[#8a7f72] mt-1">LAGOS — VI</div>
            </div>
          </button>

          <nav className="hidden lg:flex items-center gap-10">
            {(['home','about','menu','contact'] as Page[]).map(p => (
              <button key={p} onClick={() => navigate(p)} className={`relative text-[13px] tracking-[0.12em] uppercase font-medium transition-colors ${page===p ? 'text-[#0a0a0a]' : 'text-[#8a7f72] hover:text-[#0a0a0a]'}`}>
                {p}
                {page===p && <span className="absolute -bottom-2 left-0 right-0 h-[1.5px] bg-[#ff6b1a]" />}
              </button>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-3">
            <div className="text-[11px] tracking-wide text-[#8a7f72] mr-2">{orderCount>0 ? `${orderCount} in order` : 'Fresh Taste, Unforgettable Moments.'}</div>
            <button onClick={() => navigate('contact')} className="h-[42px] px-6 rounded-full bg-[#0a0a0a] text-[#fdf6ec] text-[13px] tracking-wide font-medium hover:bg-[#1e1e1e] transition-colors flex items-center gap-2">
              Reserve Table <ArrowUpRight size={16} />
            </button>
          </div>

          <button onClick={() => setMobileOpen(v=>!v)} className="lg:hidden w-10 h-10 rounded-full bg-[#0a0a0a] text-white grid place-items-center">
            {mobileOpen ? <X size={18}/> : <Menu size={18}/>}
          </button>
        </div>

        {/* mobile */}
        <div className={`lg:hidden overflow-hidden transition-all duration-500 border-t border-black/5 ${mobileOpen ? 'max-h-[380px] opacity-100' : 'max-h-0 opacity-0'}`}>
          <div className="px-6 py-8 bg-[#fffaf0] flex flex-col gap-6">
            {(['home','about','menu','contact'] as Page[]).map(p=>(
              <button key={p} onClick={()=>navigate(p)} className={`text-left text-[22px] serif tracking-tight ${page===p?'text-[#0a0a0a]':'text-[#8a7f72]'}`}>{p.toUpperCase()} <span className="text-[#ff6b1a] ml-2 text-sm">{page===p?'—':''}</span></button>
            ))}
            <button onClick={()=>navigate('contact')} className="mt-2 h-[48px] rounded-full bg-[#ff6b1a] text-white font-medium">Reserve Table</button>
            <div className="flex gap-4 text-[12px] text-[#8a7f72]">
              <span>+234 803 456 7890</span><span>•</span><span>25 VI Road, Lagos</span>
            </div>
          </div>
        </div>
      </header>

      {/* HOME PAGE */}
      <div className={page==='home' ? 'block' : 'hidden'}>
        {/* Hero */}
        <section ref={heroRef} className="relative min-h-[92vh] bg-[#0a0a0a] overflow-hidden flex">
          <div className="absolute inset-0">
            <img src={heroImg} alt="Urban Crave hero gourmet dish" className="w-full h-full object-cover opacity-[0.55]" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0a0a0a] via-[#0a0a0a]/80 to-[#0a0a0a]/10" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-transparent to-transparent" />
          </div>

          <div className="relative z-10 max-w-[1280px] mx-auto w-full px-6 lg:px-8 py-16 lg:py-24 flex flex-col lg:flex-row items-end lg:items-center gap-10">
            <div className="flex-1 max-w-[680px]">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/10 text-[11px] tracking-[0.18em] text-[#ff7a2e] uppercase mb-6">
                <span className="w-1.5 h-1.5 rounded-full bg-[#ff6b1a] animate-pulse" /> Fresh Taste, Unforgettable Moments.
              </div>
              <h1 className="serif text-[48px] lg:text-[88px] leading-[0.9] tracking-[-0.02em] text-[#fdf6ec] text-balance">
                Experience Food <span className="instrument italic font-normal text-[#ff7a2e]">Like Never</span> Before.
              </h1>
              <p className="mt-6 text-[16px] lg:text-[18px] leading-[1.6] text-[#d6cfc5] max-w-[520px]">
                A contemporary Lagos bistro where Nigerian soul meets global technique. Wood-fired grills, seasonal produce, and a dining room designed to linger in.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <button onClick={()=>navigate('menu')} className="h-[54px] px-8 rounded-full bg-[#ff6b1a] text-white text-[14px] font-medium tracking-wide hover:bg-[#ff7a2e] transition flex items-center gap-2">
                  Explore Our Menu <ArrowUpRight size={18}/>
                </button>
                <button onClick={()=>navigate('about')} className="h-[54px] px-8 rounded-full border border-white/20 text-[#fdf6ec] text-[14px] font-medium tracking-wide hover:bg-white/10 transition">
                  Our Story
                </button>
              </div>

              <div className="mt-12 grid grid-cols-3 gap-6 max-w-[420px] border-t border-white/10 pt-8">
                <div><div className="text-[28px] serif text-white">4.9</div><div className="text-[11px] tracking-widest text-[#a8a29e] uppercase">Google Rating</div></div>
                <div><div className="text-[28px] serif text-white">2019</div><div className="text-[11px] tracking-widest text-[#a8a29e] uppercase">Est. in Lagos</div></div>
                <div><div className="text-[28px] serif text-white">12k+</div><div className="text-[11px] tracking-widest text-[#a8a29e] uppercase">Happy Diners</div></div>
              </div>
            </div>

            <div className="flex-1 lg:flex justify-end hidden">
              <div className="relative w-[360px]">
                {/* floating card */}
                <div className="rounded-[28px] overflow-hidden bg-[#fffaf0] p-3 shadow-[0_30px_80px_rgba(0,0,0,0.5)] rotate-[1.5deg]">
                  <div className="rounded-[20px] overflow-hidden aspect-[4/3] relative">
                    <img src={slicedGrilledImg} alt="Featured grilled chicken" className="w-full h-full object-cover" />
                    <div className="absolute bottom-3 left-3 right-3 rounded-[14px] bg-white/90 backdrop-blur p-3 flex items-center justify-between">
                      <div><div className="text-[13px] font-semibold">Grilled Chicken & Rice</div><div className="text-[11px] text-[#8a7f72]">Chef's Special • Today</div></div>
                      <div className="text-[14px] font-bold text-[#ff6b1a]">₦8,500</div>
                    </div>
                  </div>
                </div>
                <div className="absolute -top-6 -right-6 bg-[#fdf6ec] rounded-full px-4 py-2 shadow-xl flex items-center gap-2">
                  <div className="flex -space-x-1">
                    <div className="w-6 h-6 rounded-full bg-[#0a0a0a] text-white grid place-items-center text-[10px]">A</div>
                    <div className="w-6 h-6 rounded-full bg-[#ff6b1a] text-white grid place-items-center text-[10px]">O</div>
                    <div className="w-6 h-6 rounded-full bg-[#ece3d1] grid place-items-center text-[10px]">+2</div>
                  </div>
                  <span className="text-[11px] font-medium">Loved by regulars</span>
                </div>
                <div className="absolute -bottom-8 -left-8 bg-[#0a0a0a] text-white rounded-[16px] px-4 py-3 flex items-center gap-3 shadow-xl">
                  <div className="w-8 h-8 rounded-full bg-[#ff6b1a] grid place-items-center"><Star size={14} fill="white"/></div>
                  <div><div className="text-[13px] font-semibold leading-none">4.9 • 312 reviews</div><div className="text-[11px] text-white/60 mt-1">Mon–Sat 9AM–10PM</div></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16 lg:py-24 bg-[#fdf6ec]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-[1px] bg-[#ece3d1] rounded-[24px] overflow-hidden p-[1px]">
              {[
                { icon: Leaf, title: 'Fresh Ingredients', desc: 'We source daily from Lekki farms & local markets. No shortcuts, just seasonal produce at its peak.' },
                { icon: ChefHat, title: 'Master Chefs', desc: 'Classically trained team blending French technique with Nigerian soul, led by Chef Amara.' },
                { icon: Sparkles, title: 'Unforgettable Ambience', desc: 'Warm oak, soft lighting, vinyl jazz – a Victoria Island dining room made to slow down in.' },
              ].map((f,i)=>(
                <div key={i} className="bg-[#fffaf0] p-8 lg:p-10 reveal">
                  <div className="w-12 h-12 rounded-full bg-[#0a0a0a] text-white grid place-items-center mb-6"><f.icon size={20}/></div>
                  <h3 className="serif text-[20px] leading-tight">{f.title}</h3>
                  <p className="mt-3 text-[14px] leading-[1.7] text-[#8a7f72]">{f.desc}</p>
                  <div className="mt-6 h-[1px] bg-[#ece3d1] w-12" />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Featured Meals */}
        <section className="py-16 lg:py-20 bg-[#0a0a0a] text-[#fdf6ec]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
            <div className="flex flex-wrap items-end justify-between gap-6 mb-10">
              <div>
                <div className="text-[11px] tracking-[0.2em] uppercase text-[#ff7a2e] mb-3">Today's Selection</div>
                <h2 className="serif text-[40px] lg:text-[56px] leading-[0.95] tracking-tight">Crave-worthy plates, <br/>fired with love.</h2>
              </div>
              <button onClick={()=>navigate('menu')} className="h-[44px] px-6 rounded-full border border-white/15 text-[13px] hover:bg-white/10 transition">View Full Menu</button>
            </div>

            <div className="grid md:grid-cols-3 gap-6">
              {menuItems.slice(0,3).map((m)=>(
                <div key={m.id} className="group rounded-[20px] overflow-hidden bg-[#151515] border border-white/5 reveal">
                  <div className="aspect-[4/3] overflow-hidden relative">
                    <img src={m.img} alt={m.name} className="w-full h-full object-cover group-hover:scale-[1.06] transition duration-[1.2s]" />
                    {m.tag && <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#ff6b1a] text-white text-[10px] tracking-widest uppercase">{m.tag}</div>}
                  </div>
                  <div className="p-6">
                    <div className="flex items-start justify-between gap-4">
                      <h3 className="serif text-[20px] leading-tight">{m.name}</h3>
                      <span className="text-[#ff7a2e] font-semibold text-[14px]">₦{m.price.toLocaleString()}</span>
                    </div>
                    <p className="mt-2 text-[13px] leading-[1.6] text-[#a8a29e] line-clamp-2">{m.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-[#fffaf0]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
            <div className="flex items-center gap-3 mb-10">
              <div className="w-10 h-[1px] bg-[#ff6b1a]" />
              <div className="text-[11px] tracking-[0.2em] uppercase text-[#8a7f72]">Guest Love</div>
            </div>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { name: 'Tolu Adebayo', role: 'Lagos • Regular since 2020', quote: 'The jollof is smoky, perfect, nostalgic. Urban Crave feels like home but elevated – every visit I discover something new.', rating: 5 },
                { name: 'Chisom Eze', role: 'Food Blogger • @chisom.eats', quote: 'That grilled chicken? The char, the herbs, the rice – absolute mastery. Best modern Nigerian bistro in VI, no debate.', rating: 5 },
                { name: 'David Okonkwo', role: 'London • Visiting', quote: 'We booked last minute, stayed for 3 hours. Service, music, burger – everything intentional. Lagos fine dining without pretension.', rating: 5 },
              ].map((t,i)=>(
                <div key={i} className="rounded-[20px] bg-white border border-[#ece3d1] p-7 reveal">
                  <div className="flex gap-1 mb-4">{Array.from({length:t.rating}).map((_,j)=><Star key={j} size={14} fill="#ff6b1a" className="text-[#ff6b1a]" />)}</div>
                  <Quote className="text-[#ece3d1] mb-4" size={28}/>
                  <p className="serif text-[18px] leading-[1.5] text-balance">“{t.quote}”</p>
                  <div className="mt-6 flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#0a0a0a] text-white grid place-items-center text-[12px] font-medium">{t.name.split(' ').map(n=>n[0]).join('')}</div>
                    <div><div className="text-[13px] font-semibold">{t.name}</div><div className="text-[11px] text-[#8a7f72]">{t.role}</div></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>

      {/* ABOUT PAGE */}
      <div className={page==='about' ? 'block' : 'hidden'}>
        <section className="bg-[#0a0a0a] text-[#fdf6ec] py-16 lg:py-24">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8 grid lg:grid-cols-[1.1fr_0.9fr] gap-12 items-start">
            <div className="reveal">
              <div className="text-[11px] tracking-[0.22em] uppercase text-[#ff7a2e] mb-6">Our Story • Since 2019</div>
              <h1 className="serif text-[44px] lg:text-[72px] leading-[0.9] tracking-[-0.02em]">Born in Paris, <br/><span className="instrument italic text-[#ff7a2e]">raised in Lagos.</span></h1>
              <p className="mt-8 text-[17px] leading-[1.8] text-[#d6cfc5] max-w-[560px]">
                Urban Crave started as a late-night idea in a small Paris kitchen. Chef Amara Okafor, after graduating from Le Cordon Bleu, missed the smoky jollof of her mother’s Sunday table, the peppery kick of suya, the laughter of Victoria Island.
              </p>
              <p className="mt-4 text-[15px] leading-[1.8] text-[#a8a29e] max-w-[560px]">
                She returned to Lagos in 2018 with a notebook full of French sauces and Nigerian memories. What began as a 12-seat bistro on 25 Victoria Island Road – friends, family, a single charcoal grill – became a neighborhood ritual. We kept the grill, kept the warmth, added craft.
              </p>
              <div className="mt-10 flex gap-8">
                <div><div className="serif text-[36px]">5</div><div className="text-[11px] uppercase tracking-widest text-[#8a7f72]">Years in VI</div></div>
                <div><div className="serif text-[36px]">24</div><div className="text-[11px] uppercase tracking-widest text-[#8a7f72]">Local farms</div></div>
                <div><div className="serif text-[36px]">100%</div><div className="text-[11px] uppercase tracking-widest text-[#8a7f72]">Wood-fired</div></div>
              </div>
            </div>

            <div className="relative reveal">
              <div className="rounded-[28px] overflow-hidden aspect-[4/5] bg-[#151515]">
                <img src={interiorImg} alt="Urban Crave interior warm wood and plants" className="w-full h-full object-cover" />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-[#fdf6ec] text-[#0a0a0a] rounded-[18px] p-5 shadow-xl border border-[#ece3d1] max-w-[240px]">
                <div className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Experience</div>
                <div className="serif text-[20px] leading-tight mt-2">“We cook like our grandmothers taught us – slow, patient, with gossip in the kitchen.”</div>
                <div className="mt-3 text-[12px] font-semibold">— Chef Amara Okafor</div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 lg:py-20 bg-[#fdf6ec]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
            <div className="grid md:grid-cols-3 gap-[1px] bg-[#ece3d1] rounded-[24px] overflow-hidden p-[1px]">
              {[
                { title: 'Mission', desc: 'To honor Nigerian ingredients with global technique – familiar flavors made unforgettable, without losing soul.' },
                { title: 'Values', desc: 'Seasonality over trends. Fire over shortcuts. Community over ego. Every plate respects farmer, cook, and guest.' },
                { title: 'Passion', desc: 'Food that makes you pause. A dining room that makes you stay. We chase that quiet “mmh” after the first bite.' },
              ].map((c,i)=>(
                <div key={i} className="bg-white p-8 lg:p-10 reveal">
                  <div className="w-10 h-10 rounded-full bg-[#ff6b1a] text-white grid place-items-center mb-6 text-[12px] font-bold">0{i+1}</div>
                  <h3 className="serif text-[22px]">{c.title}</h3>
                  <p className="mt-3 text-[14px] leading-[1.7] text-[#8a7f72]">{c.desc}</p>
                </div>
              ))}
            </div>

            <div className="mt-16 grid lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 rounded-[24px] overflow-hidden bg-[#0a0a0a] text-[#fdf6ec] p-8 lg:p-12 flex flex-col justify-between min-h-[360px] reveal relative">
                <img src={grilledImg} alt="Restaurant dish background" className="absolute inset-0 w-full h-full object-cover opacity-20" />
                <div className="relative z-10">
                  <div className="inline-flex px-3 py-1 rounded-full bg-white/10 border border-white/10 text-[11px] tracking-widest uppercase">Interior Gallery</div>
                  <h3 className="serif text-[32px] lg:text-[40px] leading-[0.95] mt-6 max-w-[420px]">A room designed for long lunches and louder laughter.</h3>
                </div>
                <div className="relative z-10 flex gap-3 mt-8">
                  <div className="rounded-[12px] overflow-hidden w-[120px] h-[80px]"><img src={burgerImg} alt="Burger detail" className="w-full h-full object-cover" /></div>
                  <div className="rounded-[12px] overflow-hidden w-[120px] h-[80px]"><img src={jollofImg} alt="Jollof bowl detail" className="w-full h-full object-cover" /></div>
                  <div className="rounded-[12px] overflow-hidden w-[120px] h-[80px]"><img src={slicedGrilledImg} alt="Grilled detail" className="w-full h-full object-cover" /></div>
                </div>
              </div>
              <div className="rounded-[24px] bg-[#fffaf0] border border-[#ece3d1] p-8 flex flex-col justify-between reveal">
                <div>
                  <Utensils className="text-[#ff6b1a] mb-6" />
                  <h4 className="serif text-[24px] leading-tight">Every sauce starts at 6AM. Every grill is lit by hand.</h4>
                  <p className="mt-4 text-[14px] leading-[1.7] text-[#8a7f72]">We don't do microwaves. We do reductions, fermentations, slow smokes. Come early, you'll hear the kitchen waking up.</p>
                </div>
                <div className="mt-8 pt-6 border-t border-[#ece3d1] flex items-center justify-between">
                  <div className="text-[12px] font-medium">Open Daily</div>
                  <div className="text-[12px] text-[#8a7f72]">Mon–Sat 9AM–10PM • Sun 12PM–8PM</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* MENU PAGE */}
      <div className={page==='menu' ? 'block' : 'hidden'}>
        <section className="bg-[#fdf6ec] py-12 lg:py-16 border-b border-[#ece3d1]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
            <div className="flex flex-wrap items-end justify-between gap-8">
              <div>
                <div className="text-[11px] tracking-[0.22em] uppercase text-[#ff6b1a] mb-4">Menu • Fired Daily</div>
                <h1 className="serif text-[44px] lg:text-[64px] leading-[0.9]">Simple ingredients, <br/><span className="instrument italic">big Lagos energy.</span></h1>
              </div>
              <div className="text-[14px] leading-[1.6] text-[#8a7f72] max-w-[320px]">All prices in Naira. Vegetarian options marked. Please inform us of allergies – we cook everything fresh to order.</div>
            </div>

            <div className="mt-10 flex flex-wrap gap-2">
              {(['All','Main','Street','Drinks'] as const).map(cat=>(
                <button key={cat} onClick={()=>setFilter(cat)} className={`h-[40px] px-5 rounded-full text-[13px] font-medium tracking-wide border transition ${filter===cat ? 'bg-[#0a0a0a] text-white border-[#0a0a0a]' : 'bg-white border-[#ece3d1] text-[#8a7f72] hover:border-[#0a0a0a] hover:text-[#0a0a0a]'}`}>{cat}</button>
              ))}
            </div>
          </div>
        </section>

        <section className="py-10 lg:py-16 bg-[#fffaf0]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-6">
              {filteredMenu.map(item=>(
                <div key={item.id} className="group rounded-[20px] bg-white border border-[#ece3d1] overflow-hidden flex flex-col sm:flex-row reveal hover:shadow-[0_20px_50px_rgba(10,10,10,0.08)] transition-shadow">
                  <div className="sm:w-[200px] aspect-[4/3] sm:aspect-square overflow-hidden relative shrink-0 bg-[#fdf6ec]">
                    <img src={item.img} alt={item.name} className="w-full h-full object-cover group-hover:scale-[1.05] transition duration-700" />
                    {item.tag && <div className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-[#0a0a0a] text-white text-[10px] tracking-widest uppercase">{item.tag}</div>}
                  </div>
                  <div className="p-6 flex flex-col flex-1">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <h3 className="serif text-[19px] leading-tight">{item.name}</h3>
                        <div className="mt-1 inline-flex px-2 py-0.5 rounded-full bg-[#fff1e6] text-[#ff6b1a] text-[10px] tracking-widest uppercase font-medium">{item.category}</div>
                      </div>
                      <div className="text-[16px] font-semibold text-[#ff6b1a] shrink-0">₦{item.price.toLocaleString()}</div>
                    </div>
                    <p className="mt-3 text-[13px] leading-[1.6] text-[#8a7f72] flex-1">{item.desc}</p>
                    <div className="mt-5 flex items-center gap-3">
                      <button onClick={handleAddToOrder} className="h-[38px] px-4 rounded-full bg-[#0a0a0a] text-white text-[12px] font-medium tracking-wide hover:bg-[#1e1e1e] transition">Add to order</button>
                      <span className="text-[11px] text-[#8a7f72]">Fired in ~12 min</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 rounded-[24px] overflow-hidden bg-[#0a0a0a] text-[#fdf6ec] p-[1px] reveal">
              <div className="rounded-[23px] bg-[#0a0a0a] p-8 lg:p-10 flex flex-col lg:flex-row items-center justify-between gap-6 relative overflow-hidden">
                <img src={heroImg} alt="" className="absolute inset-0 w-full h-full object-cover opacity-[0.12]" />
                <div className="relative z-10">
                  <div className="text-[11px] tracking-[0.22em] uppercase text-[#ff7a2e] mb-3">Chef's Special • Today Only</div>
                  <h3 className="serif text-[26px] lg:text-[32px] leading-tight">Tasting Menu for 2 – 5 courses + wine, <span className="text-[#ff7a2e]">₦32,000</span></h3>
                  <p className="mt-2 text-[13px] text-[#a8a29e]">Ask your server. Changes daily based on market. Includes our famous suya-spiced prawns.</p>
                </div>
                <button onClick={()=>navigate('contact')} className="relative z-10 h-[46px] px-6 rounded-full bg-[#fdf6ec] text-[#0a0a0a] text-[13px] font-medium shrink-0">Reserve for Tasting</button>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* CONTACT PAGE */}
      <div className={page==='contact' ? 'block' : 'hidden'}>
        <section className="py-12 lg:py-20 bg-[#0a0a0a] text-[#fdf6ec]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8 grid lg:grid-cols-[0.9fr_1.1fr] gap-12">
            <div className="reveal">
              <div className="text-[11px] tracking-[0.22em] uppercase text-[#ff7a2e] mb-4">Contact & Reservations</div>
              <h1 className="serif text-[44px] lg:text-[60px] leading-[0.9]">Come hungry. <br/>Leave family.</h1>
              <p className="mt-6 text-[15px] leading-[1.7] text-[#a8a29e] max-w-[420px]">Book a table, plan a private dinner, or just say hello. We reply within an hour during service hours.</p>

              <div className="mt-10 grid gap-4">
                {[
                  { icon: MapPin, label: 'Address', value: '25 Victoria Island Road, Lagos, Nigeria.' },
                  { icon: Phone, label: 'Phone', value: '+234 803 456 7890' },
                  { icon: Mail, label: 'Email', value: 'hello@urbancrave.com' },
                  { icon: Clock, label: 'Hours', value: 'Mon–Sat 9AM–10PM • Sun 12PM–8PM' },
                ].map((c,i)=>(
                  <div key={i} className="flex gap-4 p-4 rounded-[14px] bg-white/[0.04] border border-white/10">
                    <div className="w-10 h-10 rounded-full bg-white/10 grid place-items-center shrink-0"><c.icon size={16}/></div>
                    <div><div className="text-[11px] tracking-widest uppercase text-[#a8a29e]">{c.label}</div><div className="text-[14px] mt-1 font-medium">{c.value}</div></div>
                  </div>
                ))}
              </div>

              <div className="mt-8 flex items-center gap-3">
                <a href="https://instagram.com" target="_blank" rel="noopener" className="w-10 h-10 rounded-full bg-white/10 grid place-items-center hover:bg-[#ff6b1a] transition"><Instagram size={16}/></a>
                <div className="text-[13px] text-[#a8a29e]">Follow <span className="text-white font-medium">@urbancravelagos</span> for daily specials</div>
              </div>
            </div>

            <div className="bg-[#fffaf0] text-[#0a0a0a] rounded-[24px] p-6 lg:p-8 border border-[#ece3d1] reveal">
              <h3 className="serif text-[24px]">Reserve or send a message</h3>
              <p className="mt-2 text-[13px] text-[#8a7f72]">We keep your data private. No spam – only confirmation & love letters about new dishes.</p>

              <form onSubmit={handleContactSubmit} className="mt-6 grid gap-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Name *</label>
                    <input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} className="mt-1.5 w-full h-[44px] rounded-full border border-[#ece3d1] bg-white px-4 text-[14px] outline-none focus:border-[#0a0a0a]" placeholder="Amara Okafor" />
                  </div>
                  <div>
                    <label className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Email *</label>
                    <input value={form.email} onChange={e=>setForm({...form,email:e.target.value})} className="mt-1.5 w-full h-[44px] rounded-full border border-[#ece3d1] bg-white px-4 text-[14px] outline-none focus:border-[#0a0a0a]" placeholder="hello@email.com" />
                  </div>
                </div>
                <div className="grid sm:grid-cols-3 gap-4">
                  <div><label className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Phone</label><input value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} className="mt-1.5 w-full h-[44px] rounded-full border border-[#ece3d1] bg-white px-4 text-[14px] outline-none focus:border-[#0a0a0a]" placeholder="+234..." /></div>
                  <div><label className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Date</label><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} className="mt-1.5 w-full h-[44px] rounded-full border border-[#ece3d1] bg-white px-4 text-[14px] outline-none focus:border-[#0a0a0a]" /></div>
                  <div><label className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Guests</label><input type="number" min={1} value={form.guests} onChange={e=>setForm({...form,guests:e.target.value})} className="mt-1.5 w-full h-[44px] rounded-full border border-[#ece3d1] bg-white px-4 text-[14px] outline-none focus:border-[#0a0a0a]" placeholder="2" /></div>
                </div>
                <div>
                  <label className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Message *</label>
                  <textarea value={form.message} onChange={e=>setForm({...form,message:e.target.value})} rows={4} className="mt-1.5 w-full rounded-[18px] border border-[#ece3d1] bg-white p-4 text-[14px] outline-none focus:border-[#0a0a0a] resize-none" placeholder="Tell us about your reservation, allergy, or just say hi..." />
                </div>
                {formError && <div className="text-[12px] text-[#ff6b1a] bg-[#fff1e6] border border-[#ff6b1a]/20 rounded-full px-4 py-2">{formError}</div>}
                {formSuccess && <div className="text-[12px] text-[#0a0a0a] bg-[#e8f5e9] border border-[#a5d6a7] rounded-full px-4 py-2 flex items-center gap-2"><Check size={14}/> Message saved – we will reply shortly via email.</div>}
                <button disabled={formLoading} className="h-[48px] rounded-full bg-[#0a0a0a] text-white text-[14px] font-medium hover:bg-[#1e1e1e] transition flex items-center justify-center gap-2 disabled:opacity-60">
                  {formLoading ? <Loader2 size={16} className="animate-spin"/> : null}
                  {formLoading ? 'Sending...' : 'Send Message'}
                </button>
                <div className="text-[11px] text-[#8a7f72] text-center">By sending, you agree to our friendly kitchen policy – no bots, only humans.</div>
              </form>
            </div>
          </div>
        </section>

        {/* Map */}
        <section className="py-10 bg-[#fdf6ec]">
          <div className="max-w-[1280px] mx-auto px-6 lg:px-8">
            <div className="rounded-[24px] overflow-hidden border border-[#ece3d1] bg-[#fffaf0] p-[1px] reveal">
              <div className="rounded-[23px] overflow-hidden bg-[#e9e1cf] relative min-h-[420px] flex">
                {/* map faux UI */}
                <div className="absolute inset-0 opacity-[0.6]" style={{backgroundImage:`radial-gradient(#0a0a0a 0.8px, transparent 0.8px)`, backgroundSize:'22px 22px'}} />
                <div className="absolute inset-0 bg-gradient-to-br from-[#fdf6ec]/40 to-[#ece3d1]/60" />
                {/* streets */}
                <div className="absolute top-[30%] left-0 right-0 h-[2px] bg-white/60" />
                <div className="absolute top-[60%] left-0 right-0 h-[3px] bg-white/80" />
                <div className="absolute left-[40%] top-0 bottom-0 w-[2px] bg-white/60" />
                <div className="absolute left-[72%] top-0 bottom-0 w-[3px] bg-white/80" />

                <div className="relative z-10 w-full flex">
                  <div className="hidden lg:flex w-[320px] bg-white/90 backdrop-blur border-r border-[#ece3d1] p-6 flex-col gap-4">
                    <div className="text-[11px] tracking-widest uppercase text-[#8a7f72]">Location Pin</div>
                    <div className="flex gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#0a0a0a] text-white grid place-items-center"><MapPin size={16}/></div>
                      <div><div className="font-semibold text-[14px]">Urban Crave Restaurant</div><div className="text-[12px] text-[#8a7f72] mt-1">25 Victoria Island Road<br/>Lagos, Nigeria</div></div>
                    </div>
                    <div className="mt-2 grid grid-cols-2 gap-2">
                      <div className="rounded-[12px] bg-[#fdf6ec] border border-[#ece3d1] p-3"><div className="text-[11px] text-[#8a7f72] uppercase">Rating</div><div className="text-[14px] font-semibold mt-1">4.9 ★ (312)</div></div>
                      <div className="rounded-[12px] bg-[#0a0a0a] text-white p-3"><div className="text-[11px] text-white/60 uppercase">Open</div><div className="text-[13px] font-medium mt-1">Till 10PM</div></div>
                    </div>
                    <button onClick={()=>window.open('https://maps.google.com/?q=25+Victoria+Island+Road+Lagos','_blank')} className="mt-2 h-[42px] rounded-full bg-[#ff6b1a] text-white text-[13px] font-medium">Get Directions</button>
                    <div className="mt-auto text-[11px] text-[#8a7f72]">Map style – not Google API, custom canvas for privacy</div>
                  </div>

                  <div className="flex-1 relative grid place-items-center">
                    <div className="relative">
                      <div className="w-[200px] h-[200px] rounded-full bg-[#ff6b1a]/15 animate-pulse absolute -inset-10" />
                      <div className="w-[56px] h-[56px] rounded-full bg-[#0a0a0a] text-white grid place-items-center shadow-[0_10px_30px_rgba(0,0,0,0.3)] relative z-10 border-[4px] border-white">
                        <MapPin />
                      </div>
                      <div className="absolute top-[62px] left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-r-[8px] border-t-[10px] border-l-transparent border-r-transparent border-t-[#0a0a0a]" />
                    </div>
                    <div className="absolute bottom-6 left-6 right-6 lg:left-auto lg:right-6 lg:w-[320px] bg-white rounded-[16px] p-4 shadow-xl border border-[#ece3d1] lg:hidden">
                      <div className="font-semibold text-[14px]">Urban Crave Restaurant</div><div className="text-[12px] text-[#8a7f72]">25 Victoria Island Road, Lagos</div>
                    </div>
                  </div>
                </div>

                <div className="absolute top-4 right-4 z-10 bg-white rounded-full shadow border border-[#ece3d1] flex overflow-hidden">
                  <div className="px-3 py-2 text-[11px] font-medium border-r border-[#ece3d1]">Map</div>
                  <div className="px-3 py-2 text-[11px] text-[#8a7f72]">Satellite</div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* Footer */}
      <footer className="bg-[#0a0a0a] text-[#fdf6ec] border-t border-white/5">
        <div className="max-w-[1280px] mx-auto px-6 lg:px-8 py-12 lg:py-16">
          <div className="grid lg:grid-cols-[1.3fr_0.7fr_0.7fr_1fr] gap-10">
            <div>
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-white text-black grid place-items-center font-bold text-[11px] tracking-widest">UC</div>
                <div className="font-bold tracking-[0.18em] text-[14px]">URBAN CRAVE</div>
              </div>
              <p className="mt-4 text-[14px] leading-[1.7] text-[#a8a29e] max-w-[320px]">Fresh Taste, Unforgettable Moments. A modern Lagos bistro on Victoria Island Road – wood-fired, slow-cooked, deeply Nigerian.</p>
              <div className="mt-6 flex gap-2">
                <div className="h-8 px-3 rounded-full bg-white/10 text-[11px] grid place-items-center">Mon–Sat 9AM–10PM</div>
                <div className="h-8 px-3 rounded-full bg-white/10 text-[11px] grid place-items-center">Sun 12PM–8PM</div>
              </div>
            </div>
            <div>
              <div className="text-[11px] tracking-[0.2em] uppercase text-[#8a7f72] mb-4">Navigate</div>
              <div className="grid gap-2 text-[14px] text-[#d6cfc5]">
                <button onClick={()=>navigate('home')} className="text-left hover:text-white">Home</button>
                <button onClick={()=>navigate('about')} className="text-left hover:text-white">About</button>
                <button onClick={()=>navigate('menu')} className="text-left hover:text-white">Menu</button>
                <button onClick={()=>navigate('contact')} className="text-left hover:text-white">Contact</button>
              </div>
            </div>
            <div>
              <div className="text-[11px] tracking-[0.2em] uppercase text-[#8a7f72] mb-4">Visit</div>
              <div className="text-[14px] leading-[1.7] text-[#d6cfc5]">
                25 Victoria Island Road<br/>Lagos, Nigeria<br/><br/>+234 803 456 7890<br/>hello@urbancrave.com<br/>@urbancravelagos
              </div>
            </div>
            <div>
              <div className="text-[11px] tracking-[0.2em] uppercase text-[#8a7f72] mb-4">Join Crave Club</div>
              <p className="text-[13px] text-[#a8a29e]">Monthly menu drops, secret tastings, no spam.</p>
              <form onSubmit={handleNewsletter} className="mt-4 flex gap-2">
                <input value={newsletterEmail} onChange={e=>setNewsletterEmail(e.target.value)} placeholder="Your email" className="flex-1 h-[42px] rounded-full bg-white/10 border border-white/10 px-4 text-[13px] outline-none placeholder:text-white/40 focus:border-[#ff6b1a]" />
                <button className="h-[42px] px-5 rounded-full bg-[#ff6b1a] text-white text-[13px] font-medium hover:bg-[#ff7a2e] transition">Join</button>
              </form>
              {newsletterStatus && <div className="mt-2 text-[11px] text-[#ff7a2e]">{newsletterStatus}</div>}
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-white/10 flex flex-col lg:flex-row gap-4 justify-between text-[11px] tracking-wide text-[#8a7f72]">
            <div>© {new Date().getFullYear()} Urban Crave Restaurant • Lagos, Nigeria • Crafted with fire & love</div>
            <div className="flex gap-6"><span>Privacy</span><span>Terms</span><span>Made for VI</span></div>
          </div>
        </div>
      </footer>

      {/* WhatsApp */}
      <a href="https://wa.me/2348034567890" target="_blank" rel="noopener" className="fixed bottom-6 right-6 z-50 w-[56px] h-[56px] rounded-full bg-[#25D366] text-white grid place-items-center shadow-[0_12px_30px_rgba(37,211,102,0.4)] hover:scale-105 transition">
        <div className="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-20" />
        <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d="M12.04 2c-5.46 0-9.91 4.44-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.44 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm0 18c-1.5 0-2.97-.4-4.23-1.16l-.3-.18-3.12.82.83-3.04-.2-.31A7.89 7.89 0 014.13 11.9a7.94 7.94 0 017.91-7.91c2.11 0 4.09.82 5.58 2.31a7.84 7.84 0 012.33 5.58c0 4.36-3.55 7.91-7.91 7.91zm4.34-5.92c-.24-.12-1.42-.7-1.64-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.01-.37-1.92-1.18-.71-.63-1.19-1.41-1.33-1.65-.14-.24-.02-.37.1-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.2-.47-.4-.41-.54-.42h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2 0 1.18.86 2.32.98 2.48.12.16 1.69 2.58 4.1 3.62.57.25 1.02.4 1.37.51.58.18 1.1.16 1.52.1.46-.07 1.42-.58 1.62-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28z"/></svg>
      </a>

      {/* Toast */}
      <div className={`fixed bottom-6 left-1/2 -translate-x-1/2 z-[60] transition-all duration-300 ${toast ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0 pointer-events-none'}`}>
        <div className="bg-[#0a0a0a] text-white rounded-full px-5 py-3 text-[13px] font-medium shadow-2xl flex items-center gap-2 border border-white/10">
          <div className="w-6 h-6 rounded-full bg-[#ff6b1a] grid place-items-center"><Check size={12}/></div>
          {toast}
        </div>
      </div>

      {/* subtle noise */}
      <style>{`
        @media (max-width: 768px) {
          .serif { line-height: 0.95; }
        }
      `}</style>
    </div>
  );
}
